<?php
$DB['server'] = '127.0.0.1';
$DB['port'] = '3306';
$DB['user'] = 'phpmyfaq';
$DB['password'] = 'Senha@2024';
$DB['db'] = 'FAQ';
$DB['prefix'] = '';
$DB['type'] = 'mysqli';